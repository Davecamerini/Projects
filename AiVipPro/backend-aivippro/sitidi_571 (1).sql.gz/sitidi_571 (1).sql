-- phpMyAdmin SQL Dump
-- version 4.4.15.9
-- https://www.phpmyadmin.net
--
-- Host: db28.webme.it
-- Creato il: Mar 04, 2025 alle 09:32
-- Versione del server: 10.3.31-MariaDB-log
-- Versione PHP: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sitidi_571`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `00_check_subscriptions`
--

CREATE TABLE IF NOT EXISTS `00_check_subscriptions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `subscription_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `next_payment_date` date DEFAULT NULL,
  `total` decimal(10,2) NOT NULL,
  `currency` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `order_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dump dei dati per la tabella `00_check_subscriptions`
--

INSERT INTO `00_check_subscriptions` (`id`, `user_id`, `subscription_id`, `product_id`, `status`, `next_payment_date`, `total`, `currency`, `date_created`, `order_ids`) VALUES
(1, 1, 1548, 1542, 'active', '2024-08-09', 0.00, 'EUR', '2024-08-01 14:34:23', '[1547,1565,1564,1562,1554,1553,1551,1549]');

-- --------------------------------------------------------

--
-- Struttura della tabella `00_user_video_progress`
--

CREATE TABLE IF NOT EXISTS `00_user_video_progress` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `video_id` int(11) NOT NULL,
  `watched_duration` int(11) DEFAULT 0,
  `last_watched` timestamp NOT NULL DEFAULT current_timestamp(),
  `video_duration` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=110 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dump dei dati per la tabella `00_user_video_progress`
--

INSERT INTO `00_user_video_progress` (`id`, `user_id`, `video_id`, `watched_duration`, `last_watched`, `video_duration`) VALUES
(1, 1, 36, 18, '2024-08-06 15:47:51', '0'),
(2, 1, 34, 60, '2024-10-07 08:51:36', '178'),
(3, 1, 35, 76, '2024-11-14 10:45:33', '230'),
(7, 1, 42, 187, '2024-08-07 08:40:55', '0'),
(6, 1, 103, 1404, '2024-08-07 10:43:01', '1606'),
(8, 1, 96, 20, '2024-08-07 09:26:11', '202'),
(9, 1, 101, 1001, '2024-08-07 09:51:26', '1222'),
(10, 0, 34, 147, '2024-08-09 15:18:58', '178'),
(11, 1, 107, 20, '2024-09-10 14:57:52', '1177'),
(12, 1, 132, 650, '2024-10-02 10:38:43', '1846'),
(13, 13, 34, 160, '2024-10-08 09:44:33', '178'),
(14, 1, 48, 87, '2024-10-08 10:31:42', '279'),
(15, 16, 34, 20, '2024-10-14 10:11:18', '178'),
(16, 16, 35, 220, '2024-10-14 10:17:03', '230'),
(17, 16, 120, 100, '2024-10-14 12:41:18', '100'),
(18, 16, 105, 1500, '2024-10-18 12:19:02', '1513'),
(19, 16, 44, 40, '2024-10-17 10:55:01', '2425'),
(20, 16, 103, 1602, '2024-10-17 11:27:48', '1606'),
(21, 16, 96, 120, '2024-10-17 12:02:43', '202'),
(22, 18, 93, 1047, '2024-10-20 05:33:00', '1227'),
(23, 18, 95, 1221, '2024-10-20 15:13:59', '1221'),
(24, 18, 94, 1238, '2024-10-20 15:21:18', '1238'),
(25, 18, 99, 1452, '2024-10-18 18:53:17', '1495'),
(26, 18, 58, 910, '2024-10-18 18:55:06', '944'),
(27, 18, 60, 836, '2024-10-18 18:55:25', '987'),
(28, 18, 54, 1930, '2024-10-29 06:28:04', '1935'),
(29, 18, 92, 300, '2024-10-20 05:20:01', '303'),
(30, 18, 49, 200, '2024-10-20 15:28:15', '212'),
(31, 18, 52, 1679, '2024-11-03 07:13:43', '1952'),
(32, 18, 78, 40, '2024-10-20 17:38:24', '141'),
(33, 18, 75, 944, '2024-10-20 18:35:01', '952'),
(34, 18, 70, 160, '2024-10-20 19:34:33', '477'),
(35, 17, 49, 80, '2024-10-21 17:16:00', '212'),
(36, 17, 50, 3547, '2024-10-23 17:42:33', '3551'),
(37, 18, 76, 780, '2024-10-22 16:13:15', '843'),
(38, 18, 77, 300, '2024-10-22 16:21:59', '901'),
(39, 18, 110, 160, '2024-10-22 16:25:35', '179'),
(40, 18, 119, 180, '2024-10-22 16:29:12', '194'),
(41, 18, 118, 880, '2024-10-22 16:44:58', '883'),
(42, 18, 117, 280, '2024-10-23 04:44:45', '286'),
(43, 18, 116, 100, '2024-10-23 04:56:30', '472'),
(44, 18, 115, 200, '2024-10-23 05:00:00', '1146'),
(45, 18, 114, 700, '2024-10-23 05:13:38', '1005'),
(46, 17, 105, 20, '2024-10-23 17:44:05', '1513'),
(47, 17, 98, 1640, '2024-10-23 18:13:10', '1645'),
(48, 19, 26, 220, '2024-10-24 16:55:20', '233'),
(49, 19, 25, 140, '2024-10-24 16:58:30', '150'),
(50, 19, 24, 1360, '2024-11-07 13:25:14', '1378'),
(51, 17, 99, 1480, '2024-10-24 18:56:39', '1495'),
(52, 19, 23, 1040, '2024-11-17 17:17:23', '1052'),
(53, 19, 22, 1220, '2024-11-06 19:28:13', '1225'),
(54, 17, 40, 580, '2024-10-26 17:27:29', '582'),
(55, 17, 41, 660, '2024-10-26 17:39:05', '664'),
(56, 19, 21, 1420, '2024-11-18 18:20:55', '1427'),
(57, 18, 53, 1440, '2024-11-02 19:23:28', '2064'),
(58, 17, 38, 1933, '2024-10-29 20:28:40', '1933'),
(59, 18, 51, 2165, '2024-11-03 07:15:10', '2249'),
(60, 17, 53, 2060, '2024-11-05 20:02:12', '2064'),
(61, 1, 37, 640, '2024-11-14 11:00:20', '654'),
(62, 22, 90, 940, '2024-11-14 15:31:17', '956'),
(63, 22, 89, 1220, '2024-11-20 17:12:09', '1237'),
(64, 22, 88, 762, '2024-11-20 17:25:22', '764'),
(65, 23, 38, 1900, '2024-12-26 13:35:54', '1933'),
(66, 23, 42, 180, '2024-11-20 20:06:19', '190'),
(67, 23, 40, 580, '2024-11-20 20:16:30', '582'),
(68, 23, 41, 220, '2024-11-20 20:20:28', '664'),
(69, 23, 98, 1640, '2025-02-18 17:01:23', '1645'),
(70, 19, 108, 520, '2024-11-21 14:24:57', '531'),
(71, 19, 121, 1840, '2024-11-21 15:01:07', '1846'),
(72, 19, 90, 940, '2024-11-23 16:40:23', '956'),
(73, 23, 105, 1500, '2024-12-01 09:58:54', '1513'),
(74, 23, 101, 1216, '2025-01-09 09:09:22', '1222'),
(75, 23, 120, 100, '2024-12-01 09:20:05', '100'),
(76, 26, 96, 200, '2024-12-14 06:34:27', '202'),
(77, 23, 106, 1468, '2025-01-19 10:42:50', '1482'),
(78, 18, 109, 1612, '2025-01-02 21:10:08', '1612'),
(79, 18, 42, 100, '2024-12-08 16:03:30', '190'),
(80, 18, 40, 280, '2024-12-08 16:08:27', '582'),
(81, 18, 41, 602, '2024-12-08 16:10:25', '664'),
(82, 18, 38, 1380, '2024-12-08 16:11:17', '1933'),
(83, 26, 124, 160, '2024-12-13 12:43:12', '796'),
(84, 26, 34, 160, '2024-12-13 12:22:15', '178'),
(85, 26, 37, 640, '2024-12-13 12:37:58', '654'),
(86, 26, 101, 423, '2024-12-14 06:37:19', '1222'),
(87, 25, 108, 520, '2024-12-19 03:35:17', '531'),
(88, 25, 110, 160, '2024-12-19 05:36:48', '179'),
(89, 28, 99, 975, '2025-03-01 16:22:22', '1495'),
(90, 28, 100, 2538, '2024-12-21 07:16:23', '2575'),
(91, 28, 98, 1641, '2024-12-28 11:26:58', '1645'),
(92, 28, 41, 656, '2024-12-21 07:24:19', '664'),
(93, 28, 38, 997, '2024-12-21 07:26:05', '1933'),
(94, 28, 24, 1288, '2024-12-21 07:31:00', '1378'),
(95, 28, 23, 1044, '2024-12-21 07:33:34', '1052'),
(96, 28, 22, 949, '2024-12-21 10:35:09', '1225'),
(97, 28, 94, 372, '2024-12-21 07:36:26', '1238'),
(98, 28, 101, 805, '2025-03-01 16:38:07', '1222'),
(99, 28, 21, 988, '2024-12-21 10:34:33', '1427'),
(100, 33, 41, 662, '2024-12-22 07:01:49', '664'),
(101, 33, 38, 1933, '2025-01-24 10:43:49', '1933'),
(102, 29, 105, 1407, '2024-12-27 10:33:06', '1513'),
(103, 34, 105, 125, '2025-01-04 10:57:01', '1513'),
(104, 32, 80, 80, '2025-01-07 13:04:55', '171'),
(105, 28, 110, 171, '2025-01-13 18:22:01', '179'),
(106, 23, 104, 1480, '2025-01-27 17:45:50', '1487'),
(107, 23, 103, 1600, '2025-02-12 17:52:26', '1606'),
(108, 23, 99, 40, '2025-02-18 16:33:29', '1495'),
(109, 28, 43, 1679, '2025-03-01 14:33:59', '2447');

-- --------------------------------------------------------

--
-- Struttura della tabella `abbonamenti_online`
--

CREATE TABLE IF NOT EXISTS `abbonamenti_online` (
  `order_id` int(11) NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_ids` int(11) DEFAULT NULL,
  `order_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `duration` int(255) NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token_recupero` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dump dei dati per la tabella `abbonamenti_online`
--

INSERT INTO `abbonamenti_online` (`order_id`, `first_name`, `last_name`, `product_ids`, `order_status`, `order_date`, `email`, `duration`, `password`, `token_recupero`) VALUES
(2, 'ZoiYoga', 'Admin', 661, 'completed', '2023-11-14T16:49:04', 'info@zoiyoga.it', 99999999, '$2y$10$oPKSzgUIb.Ed0YJtBCMSe.3/r3bS80qTdA5upPEIKNexYbejQ/7tq', ''),
(1, 'TEST', 'TEST', 726, 'completed', '2024-02-12T16:10:23', 'sviluppo@mondored.it', 2147483647, '$2y$10$fb9UFQD3TCll9UXYnjE5YeM50AxzJhq0Yo7YcCGAuK8mz6yJJv8bi', ''),
(871, 'TEST', 'TEST', 661, 'completed', '2024-01-09T14:40:16', 'dev@redwebfactory.it', 730, '$2y$10$PkkGffxYwJ6qRapxi8AreeFhXJa0DyNdBtaF0gRT91SvN0rFbRxpy', ''),
(729, 'TEST', 'TEST', 661, 'completed', '2023-11-21T12:27:16', 'dev@mondored.it', 365, '$2y$10$PetJs1f4Dir04ZdtMN2ZZOVMsVgpgScwb8kvUw.cECGSw9FNBYFza', ''),
(1101, 'Test', 'Mensile', 726, 'completed', '2024-01-30T15:06:40', 'copyright@mondored.it', 30, '$2y$10$g1AgYmev/PIKeZ.kFfvaBOC6yLg9sPb.T78W2QrhVVYDvgUv2lBzy', ''),
(1512, 'DANIELA', 'SALERNO', 661, 'completed', '2024-06-22T13:09:13', 'batchreactor82@hotmail.com', 365, '$2y$10$8uHU5snpsUEHm9L879njPu/AOCYtF2HQ.A.jCzUUbrq74I35uH6fO', ''),
(1118, 'Paola', 'Piazzolla', 661, 'completed', '2024-02-11T18:42:57', 'paolina19p@gmail.com', 724, '$2y$10$Qi5EalhD8wMVzRQ.IvuE7.Gyh5M7cSITa8p4mfSErK1qbE0D0KkBC', ''),
(1122, 'Gloria', 'Rebuzzini', 661, 'completed', '2024-02-07T15:50:02', 'gloria.rebuzzini@svesrl.it', 365, '$2y$10$7Nxg8dy95nwfzxmdJ6HyOu4m4cpz7QVWWG9Q.UhVGQM.MEimkbxqG', ''),
(1211, 'Roberta', 'Monguzzi', 661, 'completed', '2024-03-07T09:36:19', 'roberta529@icloud.com', 366, '$2y$10$F70CmDT.vsBs3qByA6UHm./uxn8HNrEbJp8Zfb3ygtFPC.R3ApCvm', ''),
(1120, 'Alice', 'Garello', 726, 'completed', '2024-02-07T14:13:21', 'alicegarello@gmail.com', 30, '$2y$10$dA3iEUyR3GAGPVVr1R7CJeUd/fbIoWRRFnrHbCbFSFf7xU4rhRVWu', ''),
(1124, 'Martina', 'TEST', 726, 'completed', '2024-02-07T17:02:02', 'martina@mondored.it', 30, '$2y$10$v46KsreYjzxz1psm.Rkx9er6SNWknXntTPL0JCbcNamDyijDv.SQm', ''),
(1138, 'Teresa', 'Giannone', 661, 'completed', '2024-02-07T18:10:23', 'teresagiannone5@gmail.com', 365, '$2y$10$cbfuaBHL0iekv4xeLsrfPeRdqIxpKRbaoIZzBYFK3h0AlWD3Zuk8O', ''),
(1139, 'Rosy', 'BORIA', 726, 'completed', '2024-02-08T09:42:37', 'rosy.1970@hotmail.it', 30, '$2y$10$a5ZXiz8tt9pVMJ.eSNBJnOh.FCQv0.P34K08BNvufCdrc0SShQk8O', ''),
(1137, 'Federica', 'Rasà', 661, 'completed', '2024-02-07T17:55:32', 'federica.rasa@hotmail.it', 365, '$2y$10$1Vf97dZ9H/u9N9LDFn30d.f.S7eTlbXV2T6PtqC/YL7Pj6exyep6m', ''),
(1145, 'grazia', 'Quieti', 726, 'completed', '2024-02-10T18:46:26', 'grazia.quieti@studiolegalequietitarricone.it', 30, '$2y$10$bWDIxeK1wP/qWNQ3wdUkp.d5omtV3LvibE8y8mtc6As1KOdsjxNVq', ''),
(1148, 'Lisa', 'Campaci', 661, 'completed', '2024-02-12T08:36:09', 'lisa.campaci@gmail.com', 365, '$2y$10$sW3z22qn2OznR73Vu3..ce0av.nb0lNOwDlE/.dHbofb3nqb1QLMW', ''),
(1140, 'matilde', 'napoleone', 661, 'completed', '2024-02-09T10:10:09', 'tildena@libero.it', 365, '$2y$10$zAeMP6t1b49T64XplG6lRuqIBV8Eoe8h9FxvGy5QlFMldKZ5QYbg2', ''),
(1144, 'Veronica', 'Di Tuoro', 661, 'completed', '2024-02-10T00:12:56', 'veronica.dituoro@gmail.com', 365, '$2y$10$kRURYy5E6nPd4EWf9Gm7wenVR75oRG0Y8w8ZYbB3V4/MYvRRM3oC6', ''),
(1143, 'Alessandra', 'Carniglia', 661, 'completed', '2024-02-09T21:09:40', 'alessandra.carniglia3@gmail.com', 365, '$2y$10$yZGQjdDT6gsNXVqXPaWXBuq1GR4N0a369w0Uq3HM0UOTNgHOnTBlO', ''),
(1141, 'claudia', 'botta', 661, 'completed', '2024-02-09T14:25:13', 'info@piaggiark.com', 365, '$2y$10$qzjyweaumkF8zTz36dFyUu4aEqeGDRPAA/H3MZy0ClZEVyiAQWROS', ''),
(1521, 'Carmen', 'Donè', 661, 'completed', '2024-06-23T14:45:42', 'carmen.done@gmail.com', 365, '$2y$10$kt6DJiK6oZquDEouoU9gb.3ysenrTr/AJhwjzHJ77CtA3O4CzTfcK', ''),
(1487, 'Angela', 'Lauria', 661, 'completed', '2024-06-04T12:50:06', 'lauria_angela@hotmail.it', 365, '$2y$10$XE6MSgnO/9yYtgJeBT2Thed0EHanb14omWEQXTn4EpAj8mZADmiMu', ''),
(1510, 'Stefania', 'Vismara', 661, 'completed', '2024-06-22T09:53:56', 'vismarastefania@hotmail.it', 365, '$2y$10$u8BP6iyBzp98LnRJO4rvKOfngrm7H2c1YAU/GQ2PJWzKXaS/NSiz.', ''),
(1197, 'LARA', 'MORONI', 661, 'completed', '2024-02-29T17:44:24', 'moroni_lara@yahoo.it', 378, '$2y$10$RNSltdoyn0rvpFxNEyMtIOe49KHotxoRGBnkIb8hIVNzrQvzqZHDS', ''),
(1117, 'Silvia LAURA', 'Pivetti', 661, 'completed', '2024-02-11T18:16:53', 'silvia.pivetti@gmail.com', 365, '$2y$10$Zs.eAJOUEt7DHEjDAiADd.oDhEj7R876zCZuPDy35Xfg1z7/V6hnC', ''),
(1116, 'Michela', 'Fontana', 661, 'completed', '2024-02-11T17:46:43', 'michifontana@gmail.com', 365, '$2y$10$dpyYsMbbqUhMDsjdk3hIV.BPGB4ozZOn7nDbr5eC6mTY9lDtIXeIS', ''),
(1155, 'ANNA', 'LONGOBARDI', 661, 'completed', '2024-02-12T18:49:43', 'anna@107studio.it', 365, '$2y$10$sragfo7UDpHx9xptOOj2H.DLo5uoUeQCw7K/mgzDrQqMIwlosYmQm', ''),
(1209, 'Serena', 'Ragusa', 661, 'completed', '2024-03-06T18:13:09', 'serenaragusa.r@gmail.com', 365, '$2y$10$VLS0gM5rZjjWsYlrAC9v2Oa6u2Ksf3jyrYem4XvOIT86xZaaDkUey', ''),
(1157, 'BERARDETTA', 'DI CARLO', 661, 'completed', '2024-02-13T10:18:35', 'berardetta@gmail.com', 365, '$2y$10$aJ5vM6PVFdCvwhinft4KGer7VaZx.BrvipI2bLuD4u3OtKkE2mk6q', ''),
(1158, 'LAURA', 'MASSARDI', 661, 'completed', '2024-02-13T14:40:04', 'LAURINA_MI@YAHOO.IT', 365, '$2y$10$d2E3TmQZadP4rW/PG9ZMaOeE37NpVIJffqvdvijK2hyaJTap0I3Cm', ''),
(1159, 'monica', 'simone', 661, 'completed', '2024-02-13T15:15:57', 'monica.simone@konicaminolta.it', 365, '$2y$10$j1uD/cnfkAJpACx5gu9fqOWMsj6cIzDaoSqh7rO6KIc2o/vLJadfK', ''),
(1513, 'Elena', 'Ripamonti', 661, 'completed', '2024-06-22T17:34:24', 'ripamonti.elena@gmail.com', 365, '$2y$10$lbKKiijDBQKH7FEcCrtBGuRpLo9pEB5SY.kFZl86jX0ZNHyyeSfga', ''),
(1514, 'Erica', 'Ubbiali', 661, 'completed', '2024-06-22T20:13:53', 'ericaubbiali@gmail.com', 365, '$2y$10$.R78el0vI8/uT5yzBDwfveUegSRyLixLn053N1g511v.K7pq7AdVm', ''),
(1163, 'Francesca', 'Boxler', 661, 'completed', '2024-02-14T09:08:07', 'francesca.boxler@gmail.com', 365, '$2y$10$wnQcEgNcGJwpsOT4yEe2F.99YT1cxjXGTB5KFOD.yd2pQZ6ohBTQC', ''),
(1520, 'Monica', 'Di Fabrizio', 661, 'completed', '2024-06-23T13:41:42', 'monicadifabrizio@gmail.com', 365, '$2y$10$CgrN8N6QdOJxmLqTQXafkeNPTLwMkLNS6VW1ypgcxkFhkLzZAHSDe', ''),
(1165, 'MONICA', 'NEUBURGER', 661, 'completed', '2024-02-16T09:20:20', 'monicaneuburger@yahoo.it', 365, '$2y$10$WoMZDLXAnfiFsRWpX/TcJuz9oH5WlMS7iPwLfvWh5rPWese7Pyslq', ''),
(12, 'Account', 'Dimostrativo', 661, 'completed', '2024-02-12T16:10:23', 'demo@zoiyoga.it', 365, '$2y$10$VXiBGq4bJyXtyQIPSMLL4.1ffio5mekhiDA8ye.inycSJOrZT1spC', ''),
(1166, 'Paola', 'Galli', 661, 'completed', '2024-02-16T15:17:42', 'paolagalli1969@gmail.com', 365, '$2y$10$K7A.ZQeCF3l//IfutuqmJObUTtvam8zNlJczeZs5CUSkrDnYHIj4C', ''),
(1168, 'Maria', 'Lagreca', 661, 'completed', '2024-02-16T21:45:14', 'marlag17@yahoo.it', 365, '$2y$10$RB9ZFGOnu3q0uFC6Td/ZUux6HpVbiFUQr1X8nQWzunlrWyQ3hmVWu', '7dec227f88c611df1ed52ab946b34d8afd0358c5dcfb0ae1b4e183e3a99ec8ce'),
(1169, 'Romina', 'Satriano', 661, 'completed', '2024-02-17T22:15:03', 'romina.satriano87@gmail.com', 365, '$2y$10$4u0SD1pzXzahMtAwspAyBuFceS5cw8FeeicvFn3MwEzhuPy3W3ZNW', ''),
(1187, 'Cristina', 'Piolini', 661, 'completed', '2024-02-28T00:59:37', 'piolinicristina@gmail.com', 365, '$2y$10$rS.nQzayAj/hcsB0OYX5x.rcxVc0MOyvMKs8lUf9BR7poTTQK5UOe', ''),
(1167, 'Nadia', 'Perteghella', 661, 'completed', '2024-02-16T19:37:10', 'nperteghella@gmail.com', 365, '$2y$10$UrqZgMhB4fcaqdlanLbCy.efywHVUc/Q4Grswy5Ae7.GY0Qvruhey', ''),
(1171, 'Monica', 'Rozzino', 661, 'completed', '2024-02-20T08:34:25', 'tizmony@gmail.com', 365, '$2y$10$Yx66RCrGfzWgV57G/Gwuj.zrmVo8HIsQz47FWK2GQlWVzPNXGDWWa', ''),
(1172, 'Francesca', 'Saccà', 661, 'completed', '2024-02-20T14:50:18', 'francescaunfiore@gmail.com', 365, '$2y$10$lExRffg7E7NhPEnEZv/fo.yH/rSSHumGLRibsoPVEy.Tj.69KvMB.', ''),
(1176, 'Sara', 'Gualzetti', 661, 'completed', '2024-02-21T18:48:04', 'gualzetti.sara@gmail.com', 365, '$2y$10$Tn1TU6JGjdG.Bdhd1ZOzQO0p1l5mk2JEdoF83PWvTbqKy5P7vBrZe', ''),
(1177, 'Barbara', 'Verdenelli', 661, 'completed', '2024-02-22T20:54:20', 'verdeb69@yahoo.it', 365, '$2y$10$uBT4knTmSkiLniUT1rpqqeIMaq5YoYU48d.w3cuXReQfv8u1wARVC', ''),
(1180, 'FRANCESCO', 'GRECO', 661, 'completed', '2024-02-25T20:15:53', 'fragre38@gmail.com', 365, '$2y$10$JqG9TxHlBJ5D2nE8UdEOSu4.yegkyB22Uz8NfVMsn94Rp2eh3p9mq', ''),
(1181, 'Martina', 'Mazzocco', 661, 'completed', '2024-02-26T11:33:32', 'martina.mazzocco2406@gmail.com', 365, '$2y$10$xqm6lSouHwD8eWoa3rcQ6OjeRSwAD4OzJktOtzJrFOSiYncDa.de.', ''),
(1182, 'Valeria', 'Martalò', 661, 'completed', '2024-02-26T14:58:31', 'martalovaleria@gmail.com', 365, '$2y$10$iBhEMp9I4ngwHFwSHJhW.eGvBSfqZKYSa9uK6qYettBY3cgTZN/iu', ''),
(1185, 'Irene', 'Martinico', 661, 'completed', '2024-02-27T08:18:19', 'irenemartinico87@gmail.com', 365, '$2y$10$wKKFyL2vRn4dp8ns863.su2k4x.SQo1HZV/95hMIF9dd96bkD0irq', ''),
(2555, 'Customer', 'Access', 726, 'completed', '2024-02-12T16:10:23', 'jessrizz81@gmail.com', 2147483647, '$2y$10$fb9UFQD3TCll9UXYnjE5YeM50AxzJhq0Yo7YcCGAuK8mz6yJJv8bi', ''),
(1179, 'Valentina', 'Roitero', 661, 'completed', '2024-02-25T11:32:55', 'v.roitero@libero.it', 365, '$2y$10$/AwtLNs38L8XfiXqmwpXEeNlyRtNGbjxUyo1PqmGgXukgdrFdkRF.', ''),
(1178, 'Maria Luisa', 'Palladini', 661, 'completed', '2024-02-24T10:21:46', 'marialuisa.palladini@yahoo.it', 365, '$2y$10$K8BYBJO.C0262ruQ7miK2Ox65cRYM2FEEbi.j4CmB.OTQjO.nKowa', ''),
(1188, 'Rita Gemma Anna', 'Traversi', 661, 'completed', '2024-02-28T11:29:50', 'rita.traversi61@gmail.com', 365, '$2y$10$e/09nmaOIiqMTOMDQ9KiUOJu57l3lGPU4It9y4OoOGtlysWl3Ukii', '471d4ece2ac16651cf79993b88a12af872bdf91942d3c87ac3765f8095fd2376'),
(1194, 'Santa', 'Sassi', 661, 'completed', '2024-02-29T15:30:19', 'santa.sassi@gmail.com', 365, '$2y$10$j.Ve129ywvSehrnqDTu5ieVGlBerjYtRE4b9wMNY7rABklEYwnZba', ''),
(1192, 'Daniela', 'Tusa', 661, 'completed', '2024-02-29T09:02:33', 'danie.tusa@gmail.com', 365, '$2y$10$Z5LpH6gfTmwfqTLMvT2Uk.ZvDS9O47UtEjXQWUHYbtjjGZwedXt0O', ''),
(1191, 'Silvia', 'De Berti', 661, 'completed', '2024-02-28T21:27:41', 'esse.deberti@gmail.com', 365, '$2y$10$ItYvfJIZpyaq1y.Lr41yC.jeZHL/IkOW.hmSMDrkYyGSR.pe4x1KW', ''),
(1190, 'Maria Concetta', 'Pardo', 661, 'completed', '2024-02-28T17:14:21', 'mpmaria0409@gmail.com', 365, '$2y$10$c3MK7IDv4nkdufk076ND6.vs9tutal4PKKiV1K57SFJNkQsnbejf2', ''),
(1196, 'Grazia', 'Matera', 661, 'completed', '2024-02-29T17:11:25', 'grazia.matera64@icloud.com', 365, '$2y$10$Z12yErJwcNiARDjtBjEuTuEwIAfYJyz1CaB2a9Pc1Q4DjV3/dp7vm', ''),
(1199, 'Barbara', 'Bumbalo', 661, 'completed', '2024-02-29T23:07:08', 'bumbalo.barbara@gmail.com', 365, '$2y$10$2s4OBrwh7z7s7UGAoZtRRORMXecdnpNodXN6xu33K7hDe2.mBvuFG', ''),
(1200, 'Patrizia', 'Isolato', 661, 'completed', '2024-03-01T09:39:37', 'isopatty@gmail.com', 365, '$2y$10$ZkTNmKjzwYuZ7Pvrk/hveuQb0l8XQVtelL78oaqqk3z2i6B83gb/q', ''),
(1198, 'Francesca', 'Roncarati', 661, 'completed', '2024-02-29T18:31:13', 'francesca.roncarati77@gmail.com', 365, '$2y$10$ki933DecOZZP9QD5r5be..rVsgvsv6n.AYZwZglwWRo2/dHb/Zc.i', ''),
(1201, 'erika', 'carabetta', 661, 'completed', '2024-03-01T10:12:22', 'erika.carabetta@gmail.com', 365, '$2y$10$qYKmveuE/1cyXqfbFB1wteIB69l1ni...pX5pjiNbR/08e.erwD3G', ''),
(1519, 'alba', 'di nolfi', 661, 'completed', '2024-06-23T12:20:03', 'albadinolfi@netscape.net', 365, '$2y$10$HzFGr016qAkGa6aOxWO/NeQxmCc2ifyENyi8EsuprCjw5OLspx0k.', ''),
(1202, 'Bruna Angela', 'Mendozzi', 661, 'completed', '2024-03-01T15:41:47', 'brunamzz19@gmail.com', 365, '$2y$10$L23s8ihi1VlDsRqfkAa9BuheqNprhWPaz7UGO9F4x5G1L.N8/VvxK', ''),
(1208, 'Ilaria', 'Imperiali', 661, 'completed', '2024-03-06T17:22:47', 'imperiali.ilaria@gmail.com', 365, '$2y$10$HZ1wAJ/Tua3CUefOQ93ftec4c0fdhicjOj88v3lQL4FNZNSPJvrF.', ''),
(1210, 'Antonia', 'Pagano', 661, 'completed', '2024-03-07T09:11:55', 'noela.pagano@libero.it', 365, '$2y$10$O.Lwl6eYM9XSSQOtjDjGROBYtCEBdaE1RFP5.ecC7REcWXB1G2VeO', ''),
(1212, 'dalila', 'abbinante', 661, 'completed', '2024-03-07T11:09:42', 'dalyharley@gmail.com', 365, '$2y$10$F7yb7Veu5/ef9ZM2pz/USOxfXTnN27tM4ouweKlSqEw7E7/bdGJJe', ''),
(1213, 'Michela', 'Tagliabue', 661, 'completed', '2024-03-07T13:13:19', 'michela.tagliabue1987@gmail.com', 365, '$2y$10$GPYqRHMykZgDT1xDEAs5ceGaEdeHEyalCFFrBx1wgI6qyhdSrk95m', ''),
(1215, 'Eleonora', 'Garzia', 661, 'completed', '2024-03-07T15:05:28', 'garzia.eleonora@gmail.com', 365, '$2y$10$YTx8rC2nOHAjjOIpdvUk0uRK4oiFd66OVvrwsH0ps8YHLwxuUefdW', 'ad1003500ae71c9bf01f5c192378872ff7c95b5fd374245210e8594d4dc9c1ae'),
(1517, 'Elena', 'Bonazza', 661, 'completed', '2024-06-23T11:41:48', 'info@tecnicair.it', 365, '$2y$10$2hDYBA4OZo57AsQBSMdQSOAcD7iPoLsWOmtHPz8HSXBPnxMKttx9i', ''),
(1217, 'Claudia', 'Piccioni', 661, 'completed', '2024-03-07T21:43:25', 'claudia.piccioni2@gmail.com', 365, '$2y$10$YWMTZ8/no24MUvQy6fmIG.OZnwk7OZbhnSJ.YEMpkoHsoKZ.5Anq2', '8eb3457b5b1e5cea1ac5d75c16db049a8ff1bb958c370bd43a0d941df431b165'),
(1214, 'Laura', 'Olgiati', 661, 'completed', '2024-03-07T15:01:59', 'laura.olgiati18@gmail.com', 365, '$2y$10$MZhQz5/c9CnEuaEPYAZtnOMpGF68ZR5hoijKKu9wv7wATzQSgM.US', ''),
(1516, 'Emilia', 'Bareggi', 661, 'completed', '2024-06-23T00:57:22', 'bareggi.emilia@gmail.com', 365, '$2y$10$VEn4lSv477hYd0SjyjQGBOost1dN6zaujd63FMcjmyTKZoVLIyQAK', 'f6bfe96ea2da8429fe60847460e331d3defd059a6ad1a01d8102bc1187f14827'),
(1509, 'Giorgia Elena', 'Bighini', 661, 'completed', '2024-06-22T09:48:39', 'giorgiabighini@hotmail.com', 365, '$2y$10$0307NNq6BPNPjpJdVT/Vy.03Bd.TMqsGdHVPOtfARK6JMtjNINl1m', ''),
(1219, 'Ilaria', 'Rosseti', 661, 'completed', '2024-03-08T10:42:49', 'ila.rosseti@gmail.com', 365, '$2y$10$qRmeikUuZwHKWR9FBwEuyODVnkS9sP/eYrZG6IUgwymypUP6QnXmu', ''),
(1508, 'Vanessa', 'La Monica', 661, 'completed', '2024-06-21T22:07:10', 'lamonicavanessa102@gmail.com', 365, '$2y$10$EeQHGqZR79Vj69S2GoZXHep07mRlIrPhkRACSVVOkSnpwUEixu6oO', 'aeacbe82e195bb2570240011f455ca98d125932cca9a29c5e65bf2e8e15eae3e'),
(1222, 'Giada', 'Giglioli', 661, 'completed', '2024-03-08T14:08:19', 'giada.giglioli89@gmail.com', 365, '$2y$10$MDNgjf.ggPg/LtwXqqpVJu.ThpUfstI39JFugwZlzCk3qHEy0u84O', ''),
(1223, 'Erika Adelaide', 'Limonta', 661, 'completed', '2024-03-08T14:50:03', 'erikalimonta@gmail.com', 365, '$2y$10$ukFDymZW.gd3Yhbt3.5aBO.aTsqRUbawSrgV42dzq6OhQ01wWyVO6', ''),
(1224, 'Anna Maria', 'Dubois', 661, 'completed', '2024-03-08T15:56:47', 'ania.krolikowska@gmail.com', 365, '$2y$10$h/mXlM5VgZEpE8OB31.a8u5InaSLyC/dvXOo0vTNA4Rz.JRu4cqze', ''),
(1225, 'Elena', 'Valdameri', 661, 'completed', '2024-03-08T22:28:43', 'valdamerielena@gmail.com', 365, '$2y$10$0EOnNNtlwbq4NUZMbNgzt.EW40Wi4toDeJEimlAwYAMHkk1Z/cPge', ''),
(1527, 'Anna', 'Manukhina', 661, 'completed', '2024-07-04T18:15:25', 'aannamanukhina@gmail.com', 365, '$2y$10$qYw.JoL52wAlAehAEKo/muX5ehN70nZMWJ2rGErZxNxruXrmK7bkq', ''),
(1518, 'Marinella', 'Zezza', 661, 'completed', '2024-06-23T12:11:53', 'maribea@hotmail.it', 365, '$2y$10$iNukJQba0bpAeyRIPhHlNue90tgUY2kHBiu/sx3IJfvkWZXvidicu', ''),
(1226, 'Denise', 'Ferrario', 661, 'completed', '2024-03-08T22:57:06', 'deniseferrario@alice.it', 365, '$2y$10$6uzYRhkGPdOtWU6AN5J3fetDfDP27oj5wcAvbLFv6oPvlipCumMSy', ''),
(1515, 'Simona', 'Riminucci', 661, 'completed', '2024-06-22T22:00:27', 'simona.riminucci@hotmail.com', 365, '$2y$10$bscuBNnuIRrg9gUv8rA5J.DZen9oA6xhpKt1FsLjbCO8Bjju1Tmoe', ''),
(1276, 'Francesca', 'Delena', 726, 'completed', '2024-04-07T16:55:01', 'deza94@hotmail.it', 30, '$2y$10$KhdpdSQ4T.T9h2znFE0tluUjNEjUXLE06gsXyIfGOfbEKGgGFqfJS', ''),
(1511, 'Amelia', 'Russo', 661, 'completed', '2024-06-22T10:04:32', 'ameliarusso1@gmail.com', 365, '$2y$10$l2Tclmp46Qa6cIEBkfe5J.ol5LtAfKeemiO2BiQOUj39nM2.ZBcBy', ''),
(1507, 'Sara', 'Galli', 661, 'completed', '2024-06-21T14:54:58', 'sara.galli24@gmail.com', 365, '$2y$10$ndWLnvrlsaKChKbsWeI5/.cgZgmSn2iYS3BLwoBHwQ20QJvTnbcgi', ''),
(1599, 'Manuela Maria', 'Pastori', 661, 'completed', '2024-09-06T11:06:16', 'manu.mp@libero.it', 365, '$2y$10$SK2ajN1ozb.VR5IQvmWhIO9pE2BzaQj.3HcC7tg0J/EmxHuE7KPAy', ''),
(1655, 'benarda', 'petja', 661, 'completed', '2024-10-07T10:34:07', 'bena.petja@gmail.com', 365, '$2y$10$/Ddij6MXFYCWyy9..M278.oXl/A7RtOcWzy6iObJPk2XUYFcxvax.', '');

-- --------------------------------------------------------

--
-- Struttura della tabella `abbonamenti_scaduti`
--

CREATE TABLE IF NOT EXISTS `abbonamenti_scaduti` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_ids` int(11) NOT NULL,
  `order_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_date` datetime(6) NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `duration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=1264 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dump dei dati per la tabella `abbonamenti_scaduti`
--

INSERT INTO `abbonamenti_scaduti` (`id`, `first_name`, `last_name`, `product_ids`, `order_status`, `order_date`, `email`, `duration`) VALUES
(1, 'Admin', 'Admin', 661, 'completed', '2023-11-14 16:49:04.000000', 'sviluppo@mondored.it', '99999999'),
(731, 'supporto', 'TECNICo', 661, 'completed', '2023-11-21 12:56:55.000000', 'supportotecnico@mondored.it', '365'),
(862, 'Metin', 'Test', 661, 'completed', '2024-01-09 10:16:35.000000', 'dev@redwebfactory.it', '365'),
(1118, 'Paola', 'Piazzolla', 661, 'completed', '2024-02-06 18:42:57.000000', 'paolina19p@gmail.com', '365'),
(1153, 'LARA', 'MORONI', 726, 'completed', '2024-02-12 12:43:21.000000', 'moroni_lara@yahoo.it', '30'),
(1121, 'Roberta', 'Monguzzi', 726, 'completed', '2024-02-07 15:27:42.000000', 'roberta529@icloud.com', '30'),
(1227, 'CLAUDIA carolina', 'RIMOLDI', 726, 'completed', '2024-03-09 09:11:28.000000', 'crimoldi67@gmail.com', '30'),
(1111, 'Sonia', 'Alfano Di Pierro', 726, 'completed', '2024-02-04 09:00:20.000000', 'sonia.4495@hotmail.com', '30'),
(1228, 'Agnieska', 'Mackevic', 726, 'completed', '2024-03-08 11:51:22.000000', '88agnieska@gmail.com', '30'),
(1229, 'DANIELA', 'SALERNO', 726, 'completed', '2024-03-08 10:43:16.000000', 'daniela.salerno82@libero.it', '30'),
(1230, 'Nicoletta', 'Piccirillo', 726, 'completed', '2024-03-08 06:15:44.000000', 'nicoletta.piccirillo2@gmail.com', '30'),
(1231, 'Federica', 'Bianchi', 726, 'completed', '2024-03-07 16:21:29.000000', 'fedebianchi@outlook.it', '30'),
(1232, 'Viviana', 'Sciarrillo', 726, 'completed', '2024-03-02 15:15:55.000000', 'viviana.sciarrillo@alice.it', '30'),
(1233, 'Chiara', 'Orlandini', 726, 'completed', '2024-02-29 11:40:44.000000', 'chiara-orlandini@libero.it', '30'),
(1234, 'Martina', 'Truppo', 726, 'completed', '2024-02-14 14:51:23.000000', 'martina.truppo@live.it', '30'),
(1235, 'Elena', 'De Liberato', 726, 'completed', '2024-02-13 22:12:27.000000', 'delele76@gmail.com', '30'),
(1236, 'micol', 'iuculano', 726, 'completed', '2024-02-13 17:33:29.000000', 'intermicol@gmail.com', '30'),
(1237, 'Daniela', 'Dell Olio', 726, 'completed', '2024-02-12 21:39:55.000000', 'danieladellolio@yahoo.it', '30'),
(1238, 'TEST', 'TEST', 726, 'completed', '2024-02-12 16:10:23.000000', 'sviluppo@mondored.it', '30'),
(1239, 'lucia Ilaria', 'seglie', 726, 'completed', '2024-02-12 12:05:25.000000', 'lucia.seglie@gmail.com', '30'),
(1240, 'Laura', 'Manfredi', 726, 'completed', '2024-02-11 17:26:43.000000', 'lauramanfredi75@hotmail.com', '30'),
(1241, 'Deborah', 'Galbier', 726, 'completed', '2024-04-02 14:22:53.000000', 'deborahgalbier@msn.com', '30'),
(1242, 'Aliai', 'Destito', 726, 'completed', '2024-03-26 12:48:15.000000', 'aliai.d@hotmail.it', '30'),
(1243, 'Sara', 'Mendella', 726, 'completed', '2024-03-26 06:58:06.000000', 'sarahariel85@gmail.com', '30'),
(1244, 'Jharima Cristina', 'Carbajal', 726, 'completed', '2024-04-14 20:48:00.000000', 'jharidani@gmail.com', '30'),
(1245, 'Sara', 'Trentini', 726, 'completed', '2024-04-14 17:43:20.000000', 'sara.nikolas@hotmail.it', '30'),
(1246, 'Sonia', 'Alfano', 726, 'completed', '2024-04-10 13:54:49.000000', 'sonia.4495@hotmail.com', '30'),
(1247, 'CLAUDIA CAROLINA', 'RIMOLDI', 726, 'completed', '2024-04-09 07:45:31.000000', 'crimoldi67@gmail.com', '30'),
(1248, 'SARA', 'PARRAVICINI', 726, 'completed', '2024-04-05 10:09:41.000000', 'saraparravicini@hotmail.it', '30'),
(1249, 'Deborah', 'Galbier', 726, 'completed', '2024-05-04 09:21:27.000000', 'deborahgalbier@msn.com', '30'),
(1250, 'Stefania', 'Vismara', 726, 'completed', '2024-05-03 20:24:51.000000', 'vismarastefania@hotmail.it', '30'),
(1251, 'Natalie', 'Pilling', 726, 'completed', '2024-05-02 15:27:34.000000', 'natalie.s.pilling@gmail.com', '30'),
(1252, 'Deborah', 'Casella', 726, 'completed', '2024-05-21 14:48:18.000000', 'deborah.casella@live.it', '30'),
(1253, 'Silvia', 'Chiodini', 726, 'completed', '2024-05-16 09:55:34.000000', 'Vinyasa26@gmail.com', '30'),
(1254, 'Maria', 'Oliva', 726, 'completed', '2024-05-28 23:04:22.000000', 'olivaraffaella1972@gmail.com', '30'),
(1255, 'Mariela Alejandra', 'Melillo', 726, 'completed', '2024-05-27 09:41:14.000000', 'mariela.melillo@gmail.com', '30'),
(1256, 'Barbara', 'Ferrario', 726, 'completed', '2024-06-30 18:24:36.000000', 'barbara.ferrario65@gmail.com', '30'),
(1257, 'Chiara', 'Pelingotti', 726, 'completed', '2024-08-01 13:34:26.000000', 'kiartime91@gmail.com', '30'),
(1258, 'Alessandra', 'Flaminio', 726, 'completed', '2024-08-03 20:11:40.000000', 'alexaflaminio@libero.it', '30'),
(1259, 'Martina', 'Truppo', 726, 'completed', '2024-08-05 16:01:03.000000', 'martina.truppo@live.it', '30'),
(1260, 'Alfonsina', 'Pagnotta', 726, 'completed', '2024-08-08 15:22:12.000000', 'alfonsina.pagnotta2@gmail.com', '30'),
(1261, 'Antonella', 'Marelli', 726, 'completed', '2024-08-09 11:08:22.000000', 'Antmarelli@libero.it', '30'),
(1262, 'FRANCESCA', 'CICERI', 726, 'completed', '2024-08-19 20:03:45.000000', 'FRA.CICERI@VIRGILIO.IT', '30'),
(1263, 'Sara', 'Scattini', 726, 'completed', '2024-09-27 12:06:25.000000', 'scattini.sara@gmail.com', '30');

-- --------------------------------------------------------

--
-- Struttura della tabella `categorie_corsi_online`
--

CREATE TABLE IF NOT EXISTS `categorie_corsi_online` (
  `id` int(11) NOT NULL,
  `categoria` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `copertina` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dump dei dati per la tabella `categorie_corsi_online`
--

INSERT INTO `categorie_corsi_online` (`id`, `categoria`, `slug`, `copertina`) VALUES
(13, '14. Post Parto', 'post-partum', 'images/Copertina programma post parto.jpg'),
(11, '10. Visualizzazioni Guidate', 'visualizzazioni-guidate', 'images/Copertina programma visualizzazioni.jpg'),
(12, '12. Yoga e Fertilità', 'yoga-e-fertilit', 'images/Copertina programma yoga e fertilità .jpg'),
(14, '1. Presentazione Generale', 'presentazione-generale', 'images/copertina presentazione accademy.jpg'),
(15, '5. Yoga dinamico - Vinyasa', 'yoga-dinamico---vinyasa', 'images/Copertina programma vinyasa.jpg'),
(16, '3. Hatha yoga con supporti', 'hatha-yoga-con-supporti', 'images/Copertina programma yoga con supporti.jpg'),
(17, '6. Yin Yoga', 'yin-yoga', 'images/copertina Yin Yoga.jpg'),
(18, '17. Alimentazione sana, le basi', 'alimentazione-sana-le-basi', 'images/copertina corso nutrizione.jpg'),
(19, '16. Programmi speciali SOS', 'programmi-speciali-sos', 'images/Copertina programma costipazione.jpg'),
(20, '8. Respirazione e pranayama', 'respirazione-e-pranayama', 'images/copertina Pranayama.jpg'),
(21, '9. Meditazione', 'meditazione', 'images/copertina corso meditazione.jpg'),
(22, '15. Programma Posturale', 'programma-posturale', 'images/Copertina programma yoga posturale.jpg'),
(23, '13. Programma gravidanza', 'programma-gravidanza', 'images/Copertina-programma-gravidanza.jpg'),
(24, '7. Destress and relax yoga', 'destress-and-relax-yoga', 'images/copertina restorative yoga .jpg'),
(25, '4. Hatha yoga intermedio', 'hatha-yoga-intermedio', 'images/copertina programma intermedio.jpg'),
(26, '2. Hatha yoga base', 'hatha-yoga-base', 'images/Copertina Hatha yoga Base.jpg'),
(27, '11. Yoga nidra', 'yoga-nidra', 'images/copertina Yoga Nidra.jpg'),
(28, '18. Yoga e Menopausa', 'yoga-e-menopausa', 'images/copertina programma menopausa.jpg');

-- --------------------------------------------------------

--
-- Struttura della tabella `corsi_online`
--

CREATE TABLE IF NOT EXISTS `corsi_online` (
  `id` int(11) NOT NULL,
  `titolo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_inserimento` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stato` tinyint(1) NOT NULL,
  `categoria` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_video` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dump dei dati per la tabella `corsi_online`
--

INSERT INTO `corsi_online` (`id`, `titolo`, `link`, `data_inserimento`, `stato`, `categoria`, `file_video`) VALUES
(24, '2. LEZIONE 1 RESPIRARE E CREARE SPAZIO - YOGA E FERTILITà', '', '2023-12-13', 1, '12', '/area-corsi-online/php/gestionale/video/2. LEZIONE 1 RESPIRARE E CREARE SPAZIO - YOGA E FERTILITà.mp4'),
(23, '3. LEZIONE 2-TONIFICARE E STIMOLARE UTERO E OVAIE', '', '2023-12-13', 1, '12', '/area-corsi-online/php/gestionale/video/3. LEZIONE 2-TONIFICARE E STIMOLARE UTERO E OVAIE.mp4'),
(21, '5. LEZIONE 4- LASCIARE ANDARE, ACCETTARE E PREPARARSI AD ACCOGLIERE', '', '2023-12-13', 1, '12', '/area-corsi-online/php/gestionale/video/5. LEZIONE 4- LASCIARE ANDARE, ACCETTARE E PREPARARSI AD ACCOGLIERE.mp4'),
(22, '4. LEZIONE 3- RIEQUILIBRA IL SISTEMA ORMONALE E ABBASSA LA CURVA DELLO STRESS', '', '2023-12-13', 1, '12', '/area-corsi-online/php/gestionale/video/4. LEZIONE 3- RIEQUILIBRA IL SISTEMA ORMONALE E ABBASSA LA CURVA DELLO STRESS.mp4'),
(25, '1. COSA CI SERVE - YOGA E FERTILITà', '', '2023-12-13', 1, '12', '/area-corsi-online/php/gestionale/video/1. COSA CI SERVE - YOGA E FERTILITà.mp4'),
(26, '0. PRESENTAZIONE YOGA E FERTILITà', '', '2023-12-13', 1, '12', '/area-corsi-online/php/gestionale/video/0. PRESENTAZIONE YOGA E FERTILITA.mp4'),
(27, '6. LEZIONE 4 -  RECUPERA LE TUE ENERGIE- YOGA POST PARTO', '', '2023-12-13', 1, '13', '/area-corsi-online/php/gestionale/video/6. LEZIONE 4 -  RECUPERA LE TUE ENERGIE- YOGA POST PARTO.mp4'),
(28, '5. LEZIONE 3 . LIBERATI DAL DOLORE SPALLE E SCHIENA- YOGA POST PARTO', '', '2023-12-13', 1, '13', '/area-corsi-online/php/gestionale/video/5. LEZIONE 3 . LIBERATI DAL DOLORE SPALLE E SCHIENA- YOGA POST PARTO.mp4'),
(29, '4.LEZIONE 2- RAFFORZA IL PAVIMENTO PELVICO - YOGA POST PARTO', '', '2023-12-13', 1, '13', '/area-corsi-online/php/gestionale/video/4.LEZIONE 2- RAFFORZA IL PAVIMENTO PELVICO - YOGA POST PARTO.mp4'),
(30, '3. LEZIONE 1 - RIPRENDO O INIZIO YOGA DOPO IL PARTO', '', '2023-12-13', 1, '13', '/area-corsi-online/php/gestionale/video/3. LEZIONE 1 - RIPRENDO O INIZIO YOGA DOPO IL PARTO.mp4'),
(31, '2. ATTENZIONI E PRECAUZIONI - YOGA POST PARTO', '', '2023-12-13', 1, '13', '/area-corsi-online/php/gestionale/video/2. ATTENZIONI E PRECAUZIONI - YOGA POST PARTO.mp4'),
(32, '1. COSA CI SERVE - YOGA POST PARTO', '', '2023-12-13', 1, '13', '/area-corsi-online/php/gestionale/video/1. COSA CI SERVE - YOGA POST PARTO.mp4'),
(33, '0. PRESENTAZIONE YOGA POST-PARTO', '', '2023-12-13', 1, '13', '/area-corsi-online/php/gestionale/video/0. PRESENTAZIONE YOGA POST-PARTO.mp4'),
(34, '1.0 PRESENTAZIONE', '/area-corsi-online/php/gestionale/video/1.0 PRESENTAZIONE.mp4', '2023-12-13', 1, '14', '/area-corsi-online/php/gestionale/video/1.0 PRESENTAZIONE.mp4'),
(35, '1.1 COSA TI SERVE PER PRATICARE A CASA', '', '2023-12-13', 1, '14', '/area-corsi-online/php/gestionale/video/1.1 COSA TI SERVE PER PRATICARE A CASA.mp4'),
(36, '1.2 COME ORGANIZZARE LO SPAZIO E IL TEMPO', '', '2023-12-13', 1, '14', '/area-corsi-online/php/gestionale/video/1.2 COME ORGANIZZARE LO SPAZIO E IL TEMPO.mp4'),
(37, '1.3 SELF COACHING CON LUCIA', '', '2023-12-13', 1, '14', '/area-corsi-online/php/gestionale/video/1.3 SELF COACHING CON LUCIA.mp4'),
(38, '4. LEZIONE DI VINYASA YOGA', '', '2023-12-13', 1, '15', '/area-corsi-online/php/gestionale/video/4. LEZIONE DI VINYASA YOGA.mp4'),
(39, '3. LA RESPIRAZIONE NELLA PRATICA VINYASA', '', '2023-12-13', 1, '15', '/area-corsi-online/php/gestionale/video/3. LA RESPIRAZIONE NELLA PRATICA VINYASA.mp4'),
(40, '1. SURYA NAMASKARA A - B', '', '2023-12-13', 1, '15', '/area-corsi-online/php/gestionale/video/1. SURYA NAMASKARA A - B.mp4'),
(41, '2. COME ESEGUIRE CHATURANGA DANDASANA', '', '2023-12-13', 1, '15', '/area-corsi-online/php/gestionale/video/2. COME ESEGUIRE CHATURANGA DANDASANA.mp4'),
(42, '0. INTRODUZIONE VINYASA YOGA', '', '2023-12-13', 1, '15', '/area-corsi-online/php/gestionale/video/0. INTRODUZIONE VINYASA YOGA.mp4'),
(43, '5. SEQUENZA COMPLETA PER TUTTO IL CORPO-40 MIN', '', '2023-12-13', 1, '16', '/area-corsi-online/php/gestionale/video/5. SEQUENZA COMPLETA PER TUTTO IL CORPO-40 MIN.mp4'),
(44, '1. ASANA IN PIEDI - LE FONDAMENTA DELLA PRATICA', '', '2023-12-13', 1, '16', '/area-corsi-online/php/gestionale/video/1. ASANA IN PIEDI - LE FONDAMENTA DELLA PRATICA_1.mp4'),
(45, '4. SEQUENZA DISTENSIVA, CONSAPEVOLEZZA E ARRENDEVOLEZZA', '', '2023-12-13', 1, '16', '/area-corsi-online/php/gestionale/video/4. SEQUENZA DISTENSIVA, CONSAPEVOLEZZA E ARRENDEVOLEZZA.mp4'),
(46, '3. SVILUPPA LA TUA FORZA', '', '2023-12-13', 1, '16', '/area-corsi-online/php/gestionale/video/3. SVILUPPA LA TUA FORZA.mp4'),
(47, '2. I PIEGAMENTI IN AVANTI', '', '2023-12-13', 1, '16', '/area-corsi-online/php/gestionale/video/2. I PIEGAMENTI IN AVANTI.mp4'),
(48, '0.PRESENTAZIONE HATHA YOGA CON SUPPORTI', '', '2023-12-13', 1, '16', '/area-corsi-online/php/gestionale/video/0.PRESENTAZIONE HATHA YOGA CON SUPPORTI.mp4'),
(49, '1.0 PRESENTAZIONE YIN YOGA', '', '2023-12-13', 1, '17', '/area-corsi-online/php/gestionale/video/1.0 PRESENTAZIONE YIN YOGA.mp4'),
(50, '1.1 PRATICA COMPLETA PER IL TESSUTO CONNETTIVO', '', '2023-12-13', 1, '17', '/area-corsi-online/php/gestionale/video/1.1 PRATICA COMPLETA PER IL TESSUTO CONNETTIVO.mp4'),
(51, '1.2 APERTURE E RESPIRAZIONE', '', '2023-12-13', 1, '17', '/area-corsi-online/php/gestionale/video/1.2 APERTURE E RESPIRAZIONE.mp4'),
(52, '1.3 SCHIENA E ZONA LOMBARE', '', '2023-12-13', 1, '17', '/area-corsi-online/php/gestionale/video/1.3 SCHIENA E ZONA LOMBARE.mp4'),
(53, '1.4 SBLOCCARE IL BACINO', '', '2023-12-13', 1, '17', '/area-corsi-online/php/gestionale/video/1.4 SBLOCCARE IL BACINO.mp4'),
(54, '1.5 CALMA E SERENITÀ', '', '2023-12-13', 1, '17', '/area-corsi-online/php/gestionale/video/1.5 CALMA E SERENITA.mp4'),
(55, '1 PRESENTAZIONE ALIMENTAZIONE SANA LE BASI', '', '2023-12-13', 1, '18', '/area-corsi-online/php/gestionale/video/1 PRESENTAZIONE ALIMENTAZIONE SANA LE BASI.mp4'),
(56, '2.COSA MANGIARE', '', '2023-12-13', 1, '18', '/area-corsi-online/php/gestionale/video/2.COSA MANGIARE.mp4'),
(57, '3. QUANDO MANGIARE', '', '2023-12-13', 1, '18', '/area-corsi-online/php/gestionale/video/3. QUANDO MANGIARE.mp4'),
(58, '4. COME MANGIARE', '', '2023-12-13', 1, '18', '/area-corsi-online/php/gestionale/video/4. COME MANGIARE.mp4'),
(59, '5. COSA EVITARE', '', '2023-12-13', 1, '18', '/area-corsi-online/php/gestionale/video/5. COSA EVITARE.mp4'),
(60, '6.BUONE ABITUDINI', '', '2023-12-13', 1, '18', '/area-corsi-online/php/gestionale/video/6.BUONE ABITUDINI.mp4'),
(61, '7.EXTRA.mp4', '', '2023-12-13', 1, '18', '/area-corsi-online/php/gestionale/video/7.EXTRA.mp4'),
(62, '1.PRESENTAZIONE PROGRAMMI SPECIALI', '', '2023-12-13', 1, '19', '/area-corsi-online/php/gestionale/video/1.PRESENTAZIONE PROGRAMMI SPECIALI.mp4'),
(63, 'S.O.S. COSTIPAZIONE', '', '2023-12-13', 1, '19', '/area-corsi-online/php/gestionale/video/S.O.S. COSTIPAZIONE.mp4'),
(64, 'S.O.S. ACIDITà DI STOMACO', '', '2023-12-13', 1, '19', '/area-corsi-online/php/gestionale/video/S.O.S. ACIDITà DI STOMACO.mp4'),
(65, 'S.O.S FIBRIOMALGIA - LA ROUTINE DELLA SERA', '', '2023-12-13', 1, '19', '/area-corsi-online/php/gestionale/video/S.O.S FIBRIOMALGIA - LA ROUTINE DELLA SERA.mp4'),
(66, 'S.O.S. FIBROMIALGIA - ROUTINE DEL MATTINO', '', '2023-12-13', 1, '19', '/area-corsi-online/php/gestionale/video/S.O.S. FIBRIOMALGIA - ROUTINE DEL MATTINO.mp4'),
(67, 'S.O.S. INSONNIA', '', '2023-12-13', 1, '19', '/area-corsi-online/php/gestionale/video/S.O.S. INSONNIA.mp4'),
(68, '2.1 PRESENTAZIONE RESPIRAZIONE E PRANAYAMA', '', '2023-12-13', 1, '20', '/area-corsi-online/php/gestionale/video/2.1 PRESENTAZIONE RESPIRAZIONE E PRANAYAMA.mp4'),
(69, '1.1 COSA SONO I PRANAYAMA', '', '2023-12-13', 1, '20', '/area-corsi-online/php/gestionale/video/1.1 COSA SONO I PRANAYAMA.mp4'),
(70, '1.2 TECNICHE DI RESPIRAZIONI SEMPLICI', '', '2023-12-13', 1, '20', '/area-corsi-online/php/gestionale/video/TECNICHE DI RESPIRAZIONE.mp4'),
(71, '1.3 RESPIRO YOGICO COMPLETO', '', '2023-12-13', 1, '20', '/area-corsi-online/php/gestionale/video/1.3 RESPIRO YOGICO COMPLETO.mp4'),
(72, '1.4 ANULOM VILOM PRESENTAZIONE', '', '2023-12-13', 1, '20', '/area-corsi-online/php/gestionale/video/1.4 ANULOM VILOM PRESENTAZIONE.mp4'),
(73, '1.4 ANULOM VILOM PRATICA', '', '2023-12-13', 1, '20', '/area-corsi-online/php/gestionale/video/1.4 ANULOM VILOM PRATICA.mp4'),
(74, '1.0 PRESENTAZIONE PROGRAMMA MEDITAZIONE', '', '2023-12-13', 1, '21', '/area-corsi-online/php/gestionale/video/1.0 PRESENTAZIONE PROGRAMMA MEDITAZIONE.mp4'),
(75, '1.2 MEDITAZIONE SUGLI ELEMENTI', '', '2023-12-13', 1, '21', '/area-corsi-online/php/gestionale/video/1.2 MEDITAZIONE SUGLI ELEMENTI.mp4'),
(76, '1.3 MEDITAZIONE SUI CHAKRA', '', '2023-12-13', 1, '21', '/area-corsi-online/php/gestionale/video/1.3 MEDITAZIONE SUI CHAKRA.mp4'),
(77, '1.4 MEDITAZIONE KAYOTSARG', '', '2023-12-13', 1, '21', '/area-corsi-online/php/gestionale/video/1.4 MEDITAZIONE KAYOTSARG.mp4'),
(78, '1.1 COS''è LA MEDITAZIONE', '', '2023-12-13', 1, '21', '/area-corsi-online/php/gestionale/video/1.1 COS''è LA MEDITAZIONE.mp4'),
(79, '1.COLLO E SPALLE', '', '2023-12-13', 1, '22', '/area-corsi-online/php/gestionale/video/1.COLLO E SPALLE.mp4'),
(80, '0.PRESENTAZIONE YOGA POSTURALE', '', '2023-12-13', 1, '22', '/area-corsi-online/php/gestionale/video/0.PRESENTAZIONE YOGA POSTURALE.mp4'),
(81, '2.BACINO SANO', '', '2023-12-13', 1, '22', '/area-corsi-online/php/gestionale/video/2.BACINO SANO.mp4'),
(82, '5.PER TUTTA LA SCHIENA', '', '2023-12-13', 1, '22', '/area-corsi-online/php/gestionale/video/5.PER TUTTA LA SCHIENA.mp4'),
(83, '3.ZONA LOMBARE RILASSATA', '', '2023-12-13', 1, '22', '/area-corsi-online/php/gestionale/video/3.ZONA LOMBARE RILASSATA.mp4'),
(84, '4.ZONA LOMBARE FORTE', '', '2023-12-13', 1, '22', '/area-corsi-online/php/gestionale/video/4.ZONA LOMBARE FORTE.mp4'),
(85, 'saluto al sole in gravidanza', '', '2023-12-13', 1, '23', '/area-corsi-online/php/gestionale/video/saluto al sole in gravidanza.mp4'),
(110, '0. PRESENTAZIONE VISUALIZZAZIONI GUIDATE', '', '2023-12-13', 1, '11', '/area-corsi-online/php/gestionale/video/0. PRESENTAZIONE VISUALIZZAZIONI GUIDATE.mp4'),
(87, 'riequilibrare il sistema nervoso_parte 2', '', '2023-12-13', 1, '23', '/area-corsi-online/php/gestionale/video/riequilibrare il sistema nervoso_parte 2.mp4'),
(88, 'riequilibrare il sistema nervoso_parte 1', '', '2023-12-13', 1, '23', '/area-corsi-online/php/gestionale/video/riequilibrare il sistema nervoso_parte 1.mp4'),
(89, 'creare spazio', '', '2023-12-13', 1, '23', '/area-corsi-online/php/gestionale/video/creare spazio.mp4'),
(90, 'aumentare la nostra energia', '', '2023-12-13', 1, '23', '/area-corsi-online/php/gestionale/video/aumentare la nostra energia.mp4'),
(91, 'rilassamento guidato in gravidanza-Lucia Ilaria Seglie', '', '2023-12-13', 1, '23', '/area-corsi-online/php/gestionale/video/rilassamento guidato in gravidanza-Lucia Ilaria Seglie.mp4'),
(92, '0.1 PRESENTAZIONE DESTRESS E RELAX YOGA', '', '2023-12-13', 1, '24', '/area-corsi-online/php/gestionale/video/0.1 PRESENTAZIONE DESTRESS E RELAX YOGA.mp4'),
(93, '0.2RESTORATIVE SHAVASANA', '', '2023-12-13', 1, '24', '/area-corsi-online/php/gestionale/video/0.2RESTORATIVE SHAVASANA.mp4'),
(94, '0.4 RESTORATIVE YOGA CONTROLLO DEI LIVELLI DI STRESS', '', '2023-12-13', 1, '24', '/area-corsi-online/php/gestionale/video/0.4 RESTORATIVE YOGA CONTROLLO DEI LIVELLI DI STRESS.mp4'),
(95, '0.3 RESTORATIVE LASCIARE ANDARE', '', '2023-12-13', 1, '24', '/area-corsi-online/php/gestionale/video/0.3 RESTORATIVE LASCIARE ANDARE.mp4'),
(96, '0. PRESENTAZIONE HATHA YOGA INTERMEDIO', '', '2023-12-13', 1, '25', '/area-corsi-online/php/gestionale/video/0. PRESENTAZIONE HATHA YOGA INTERMEDIO.mp4'),
(97, 'RESPIRAZIONE E MEDITAZIONE HATHA YOGA INTERMEDIO', '', '2023-12-13', 1, '25', '/area-corsi-online/php/gestionale/video/RESPIRAZIONE E MEDITAZIONE HATHA YOGA INTERMEDIO.mp4'),
(98, 'LEZIONE 1 HATHA YOGA INTERMEDIO', '', '2023-12-13', 1, '25', '/area-corsi-online/php/gestionale/video/LEZIONE 1 HATHA YOGA INTERMEDIO.mp4'),
(99, 'UNA PRATICA GIORNALIERA', '', '2023-12-13', 1, '25', '/area-corsi-online/php/gestionale/video/UNA PRATICA GIORNALIERA.mp4'),
(100, 'LEZIONE DI 40 MIN HATHA YOGA INTERMEDIO', '', '2023-12-13', 1, '25', '/area-corsi-online/php/gestionale/video/LEZIONE DI 40 MIN HATHA YOGA INTERMEDIO.mp4'),
(101, 'LEZIONE 20 MIN HATHA YOGA INTERMEDIO', '', '2023-12-13', 1, '25', '/area-corsi-online/php/gestionale/video/LEZIONE 20 MIN HATHA YOGA INTERMEDIO.mp4'),
(121, 'YOGA NIDRA', '/area-corsi-online/php/gestionale/video/Yoga-Nidra-intermedio.mp3', '2024-02-28', 1, '27', '/area-corsi-online/php/gestionale/video/Yoga-Nidra-intermedio.mp3'),
(103, '4.LEZIONE 4 HATHA YOGA BASE', '', '2023-12-13', 1, '26', '/area-corsi-online/php/gestionale/video/4.LEZIONE 4 HATHA YOGA BASE.mp4'),
(104, '3. LEZIONE 3 HATHA YOGA BASE', '', '2023-12-13', 1, '26', '/area-corsi-online/php/gestionale/video/3. LEZIONE 3 HATHA YOGA BASE.mp4'),
(105, '1. LEZIONE 1 HATHA YOGA BASE', '', '2023-12-13', 1, '26', '/area-corsi-online/php/gestionale/video/1. LEZIONE 1 HATHA YOGA BASE.mp4'),
(106, '2. LEZIONE 2 HATHA YOGA BASE', '', '2023-12-13', 1, '26', '/area-corsi-online/php/gestionale/video/2. LEZIONE 2 HATHA YOGA BASE.mp4'),
(107, 'AUDIO RILASSAMENTO FINALE HATHA YOGA BASE', '/area-corsi-online/php/gestionale/video/AUDIO_RILASSAMENTO FINALE HATHA YOGA BASE.mp3', '2023-12-13', 1, '26', '/area-corsi-online/php/gestionale/video/AUDIO_RILASSAMENTO FINALE HATHA YOGA BASE.mp3'),
(108, 'YOGA NIDRA PRESENTAZIONE', '/area-corsi-online/php/gestionale/video/YOGA NIDRA PRESENTAZIONE.mp4', '2023-12-13', 1, '27', '/area-corsi-online/php/gestionale/video/YOGA NIDRA PRESENTAZIONE.mp4'),
(109, 'AUDIO YOGA NIDRA PRATICA INTERMEDIA', '', '2023-12-13', 1, '27', '/area-corsi-online/php/gestionale/video/AUDIO_YOGA NIDRA PRATICA INTERMEDIA.mp3'),
(111, '7. Visualizzazione del Perdono', '', '2023-12-13', 1, '11', '/area-corsi-online/php/gestionale/video/7. Visualizzazione del Perdono.mp3'),
(112, '6. Introduzione alla visualizzazione del Perdono', '/area-corsi-online/php/gestionale/video/6. Introduzione alla visualizzazione del Perdono.mp3', '2023-12-13', 1, '11', '/area-corsi-online/php/gestionale/video/6. Introduzione alla visualizzazione del Perdono.mp3'),
(113, '5. Come creare la trasformazione', '/area-corsi-online/php/gestionale/video/5. Come creare la trasformazione.mp3', '2023-12-13', 1, '11', '/area-corsi-online/php/gestionale/video/5. Come creare la trasformazione.mp3'),
(114, '4.Accettare senza giudizio', '', '2023-12-13', 1, '11', '/area-corsi-online/php/gestionale/video/4.Accettare senza giudizio.mp3'),
(115, '4. Visualizzazione della Consapevolezza', '', '2023-12-13', 1, '11', '/area-corsi-online/php/gestionale/video/4. Visualizzazione della Consapevolezza.mp3'),
(116, '3.2. Ci prepariamo alla Visualizzazione', '', '2023-12-13', 1, '11', '/area-corsi-online/php/gestionale/video/3.2. Ci prepariamo alla Visualizzazione.mp3'),
(117, '3.1. Ci prepariamo alla visualizzazione', '', '2023-12-13', 1, '11', '/area-corsi-online/php/gestionale/video/3.1. Ci prepariamo alla visualizzazione.mp3'),
(118, '2. Come funziona la nostra mente e il potere del respiro', '', '2023-12-13', 1, '11', '/area-corsi-online/php/gestionale/video/2. Come funziona la nostra mente e il potere del respiro.mp3'),
(119, '1. Introduzione al corso', '', '2023-12-13', 1, '11', '/area-corsi-online/php/gestionale/video/1. Introduzione al corso.mp3'),
(120, '0.PRESENTAZIONE HATHA YOGA BASE', '', '2024-02-28', 1, '26', '/area-corsi-online/php/gestionale/video/0.PRESENTAZIONE HATHA YOGA BASE.mp4'),
(122, '1. Disturbi del Sonno, Sbalzi d’Umore e Irritabilità', '', '2024-07-30', 1, '28', '/area-corsi-online/php/gestionale/video/1. Disturbi del Sonno, Sbalzi d’Umore e Irritabilità.mp4'),
(123, '2. Vampate di Calore', NULL, '2024-07-30', 1, '28', '/area-corsi-online/php/gestionale/video/2. Vampate di Calore.mp4'),
(124, '3. Capelli e Pelle', NULL, '2024-07-30', 1, '28', '/area-corsi-online/php/gestionale/video/3. Capelli e Pelle.mp4'),
(125, '4. Secchezza Vaginale', NULL, '2024-07-30', 1, '28', '/area-corsi-online/php/gestionale/video/4. Secchezza Vaginale.mp4');

-- --------------------------------------------------------

--
-- Struttura della tabella `subscriptions`
--

CREATE TABLE IF NOT EXISTS `subscriptions` (
  `id` int(11) NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `products` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `next_payment_date` datetime DEFAULT NULL,
  `total_spent` decimal(10,2) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dump dei dati per la tabella `subscriptions`
--

INSERT INTO `subscriptions` (`id`, `date_created`, `status`, `customer_email`, `products`, `next_payment_date`, `total_spent`, `customer_id`) VALUES
(1548, '2024-08-01 14:34:23', 'active', 'sviluppo@mondored.it', 'Prodotto: TEST giornaliero (ID: 1542)', '2024-10-08 16:50:04', 0.00, 1),
(1666, '2024-10-08 10:58:54', 'active', 'socialmedia@mondored.it', 'Prodotto: Abbonamento Mensile - Piattaforma Online (ID: 1657)', '2025-03-08 09:11:52', 0.00, 13),
(1687, '2024-10-11 11:31:45', 'on-hold', 'yleniavanelli@hotmail.it', 'Prodotto: Abbonamento Mensile - Piattaforma Online (ID: 1657)', '2024-12-21 09:33:28', 29.00, 16),
(1690, '2024-10-16 20:09:12', 'on-hold', 'ilaria.fredianelli@gmail.com', 'Prodotto: Abbonamento Mensile - Piattaforma Online (ID: 1657)', '2024-11-16 18:09:12', 29.00, 17),
(1692, '2024-10-18 20:21:12', 'cancelled', 'crimoldi67@gmail.com', 'Prodotto: Abbonamento Mensile - Piattaforma Online (ID: 1657)', '0000-00-00 00:00:00', 29.00, 18),
(1694, '2024-10-21 15:50:43', 'on-hold', 'marchi.lorenza@gmail.com', 'Prodotto: Abbonamento Mensile - Piattaforma Online (ID: 1657)', '2024-12-23 06:51:03', 29.00, 19),
(1712, '2024-11-11 14:21:49', 'cancelled', 'elena.cricelli@gmail.com', 'Prodotto: Abbonamento Mensile - Piattaforma Online (ID: 1657)', '0000-00-00 00:00:00', 29.00, 22),
(1720, '2024-11-18 23:42:36', 'active', 'a.gagliano81@gmail.com', 'Prodotto: Abbonamento Annuale - Piattaforma Online (ID: 1659)', '2025-11-18 22:42:36', 250.00, 23),
(1725, '2024-11-26 09:31:25', 'active', 'carogasp@hotmail.it', 'Prodotto: Abbonamento Annuale - Piattaforma Online (ID: 1659)', '2025-11-26 08:31:25', 250.00, 25),
(1728, '2024-12-02 01:29:28', 'active', 'sangreari@gmail.com', 'Prodotto: Abbonamento Annuale - Piattaforma Online (ID: 1659)', '2025-12-02 00:29:27', 250.00, 26),
(1948, '2024-12-13 10:17:36', 'active', 'fiamma.colette@gmail.com', 'Prodotto: Abbonamento Annuale - Piattaforma Online (ID: 1659)', '2025-12-13 09:17:35', 250.00, 28),
(1951, '2024-12-18 20:57:52', 'active', 'isopatty@gmail.com', 'Prodotto: Abbonamento Annuale - Piattaforma Online (ID: 1659)', '2025-12-18 19:57:52', 250.00, 29),
(1956, '2024-12-20 17:00:49', 'on-hold', 'andrea.insinga@crescendosoftware.com', 'Prodotto: Abbonamento Mensile - Piattaforma Online (ID: 1657)', '2024-12-31 16:00:49', 29.00, 31),
(1959, '2024-12-20 23:13:19', 'active', 'laura.bi46@hotmail.it', 'Prodotto: Abbonamento Annuale - Piattaforma Online (ID: 1659)', '2025-12-20 22:13:19', 250.00, 32),
(1961, '2024-12-21 08:46:36', 'active', 'mmartapacilli98@gmail.com', 'Prodotto: Abbonamento Annuale - Piattaforma Online (ID: 1659)', '2025-12-21 07:46:35', 250.00, 33),
(1964, '2024-12-23 00:06:22', 'active', 'g_lusso@alice.it', 'Prodotto: Abbonamento Annuale - Piattaforma Online (ID: 1659)', '2025-12-22 23:06:22', 250.00, 34),
(1970, '2024-12-24 18:31:30', 'on-hold', 'guya.silva@flavourland.com', 'Prodotto: Abbonamento Mensile - Piattaforma Online (ID: 1657)', '2025-01-24 17:31:30', 29.00, 36),
(1972, '2024-12-25 17:52:30', 'active', 'aliai.d@hotmail.it', 'Prodotto: Abbonamento Annuale - Piattaforma Online (ID: 1659)', '2025-12-25 16:52:29', 250.00, 37),
(1974, '2024-12-24 18:31:30', 'cancelled', 'guya.silva@flavourland.com', 'Prodotto: Abbonamento Mensile - Piattaforma Online (ID: 1657)', '0000-00-00 00:00:00', 29.00, 36),
(1977, '2024-12-31 14:30:41', 'cancelled', 'guya.silva@flavourland.com', 'Prodotto: Abbonamento Mensile - Piattaforma Online (ID: 1657)', '0000-00-00 00:00:00', 29.00, 36),
(2352, '2025-01-09 16:01:12', 'active', 'ila.rosseti@gmail.com', 'Prodotto: Abbonamento Annuale - Piattaforma Online (ID: 1659)', '2026-03-08 15:00:55', 250.00, 38);

-- --------------------------------------------------------

--
-- Struttura della tabella `video_tokens`
--

CREATE TABLE IF NOT EXISTS `video_tokens` (
  `id` int(11) NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration_date` datetime NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=1052 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dump dei dati per la tabella `video_tokens`
--

INSERT INTO `video_tokens` (`id`, `token`, `expiration_date`) VALUES
(1051, '38e3cb9b445e7d16634b6d0d1088355bfb49c19270166325092af72142c6127a', '2025-03-04 00:07:57');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `00_check_subscriptions`
--
ALTER TABLE `00_check_subscriptions`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `00_user_video_progress`
--
ALTER TABLE `00_user_video_progress`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `video_id` (`video_id`);

--
-- Indici per le tabelle `abbonamenti_online`
--
ALTER TABLE `abbonamenti_online`
  ADD PRIMARY KEY (`order_id`),
  ADD UNIQUE KEY `order_id` (`order_id`);

--
-- Indici per le tabelle `abbonamenti_scaduti`
--
ALTER TABLE `abbonamenti_scaduti`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `categorie_corsi_online`
--
ALTER TABLE `categorie_corsi_online`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `corsi_online`
--
ALTER TABLE `corsi_online`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `video_tokens`
--
ALTER TABLE `video_tokens`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `00_check_subscriptions`
--
ALTER TABLE `00_check_subscriptions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT per la tabella `00_user_video_progress`
--
ALTER TABLE `00_user_video_progress`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=110;
--
-- AUTO_INCREMENT per la tabella `abbonamenti_scaduti`
--
ALTER TABLE `abbonamenti_scaduti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1264;
--
-- AUTO_INCREMENT per la tabella `categorie_corsi_online`
--
ALTER TABLE `categorie_corsi_online`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT per la tabella `corsi_online`
--
ALTER TABLE `corsi_online`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=133;
--
-- AUTO_INCREMENT per la tabella `video_tokens`
--
ALTER TABLE `video_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1052;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
